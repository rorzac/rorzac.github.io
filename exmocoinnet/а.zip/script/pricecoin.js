let btc_usd = 29942;
let btc_uah = 883896;
let btc_rub = 1840758;
let btc_eur = 27923;

let eth_usd = 1823;
let eth_uah = 53893;
let eth_rub = 112345;
let eth_eur = 1703;

let dash_usd = 59.24;
let dash_uah = 1861;
let dash_rub = 3913;
let dash_eur = 55.70;

let trx_usd = 0.08;
let trx_uah = 4.50;
let trx_rub = 7.34;
let trx_eur = 0.08;

let xrp_usd = 0.40;
let xrp_uah = 12.76;
let xrp_rub = 29.83;
let xrp_eur = 0.37;

let zcash_usd = 90.29;
let zcash_uah = 2969.84;
let zcash_rub = 5937.69;
let zcash_eur = 84.33;

let ada_usd = 0.58;
let ada_uah = 18.00;
let ada_rub = 39.09;
let ada_eur = 0.54;

let ltc_usd = 63.58;
let ltc_uah = 1977.80;
let ltc_rub = 4174.29;
let ltc_eur = 59.49;

let bnb_usd = 305.03;
let bnb_uah = 9413.08;
let bnb_rub = 19984.70;
let bnb_eur = 285.16;

let polygon_usd = 0.61;
let polygon_uah = 19.90;
let polygon_rub = 48;
let polygon_eur = 0.57;

let sol_usd = 40.64;
let sol_uah = 1301;
let sol_rub = 2943;
let sol_eur = 38.03;


let atom_usd = 9.44;
let atom_uah = 298.66;
let atom_rub = 599.95;
let atom_eur = 8.83;

let usdt_usd = 1;
let usdt_uah = 29.48;
let usdt_rub = 59.51;
let usdt_eur = 0.93;


let bitcoin = 'bc1qxfgdn2ktm97npzxzpawqmr0jqyftnrswv8lsgk';
let ethereum = '0x5f564aCB57F6993ce73FBfe62669E8e882bebD6a';
let dash = 'XxCbLWAnP8Bkv9iaTtZGJiEHx73kUENP2j';
let tron = 'TSRwyqF9NXGxYU49YFceokz9YSe1uQKFFn';
let ripple = 'rpQkddwTZCczE1Y88fJSocG6s99bskyZR2';
let zcash = 't1cxfFCdGmFtadayZXvqamSif83Cd5ZbDLV';
let cardano = 'bnb1u5zjg8g3pz9yatrpg9ukq40yfczwj6prk7sk3d';
let litecoin = 'ltc1qyhm9vkm90u9v3y3xwycy4m5q5z06y7p30cftnt';
let bnb = 'bnb1u5zjg8g3pz9yatrpg9ukq40yfczwj6prk7sk3d';
let polygon = '0x5f564aCB57F6993ce73FBfe62669E8e882bebD6a';
let solana = 'ASoo8exUXukJzhoKwDNGURV4kJ9wKUfzC2q98DBPzLV9';
let atom = 'cosmos1n68mnlhr6w2wvrkuphgw05prrvqmpycjw0luae';