let toncoin_usdt = 1.34;

