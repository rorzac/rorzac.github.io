let btc_usd = 29942;
let btc_uah = 883896;
let btc_rub = 1840758;
let btc_eur = 27923;

let eth_usd = 1823;
let eth_uah = 38597;
let eth_rub = 81684;
let eth_eur = 1703;

let dash_usd = 59.24;
let dash_uah = 1461;
let dash_rub = 2913;
let dash_eur = 55.70;

let trx_usd = 0.11;
let trx_uah = 2.50;
let trx_rub = 4.5;
let trx_eur = 0.10;

let xrp_usd = 0.45;
let xrp_uah = 11;
let xrp_rub = 19;
let xrp_eur = 0.40;

let zcash_usd = 90.29;
let zcash_uah = 2269.84;
let zcash_rub = 4237.69;
let zcash_eur = 84.33;

let ada_usd = 0.61;
let ada_uah = 15.00;
let ada_rub = 28.09;
let ada_eur = 0.59;

let ltc_usd = 63.58;
let ltc_uah = 1377.80;
let ltc_rub = 2574.29;
let ltc_eur = 59.49;

let bnb_usd = 305.03;
let bnb_uah = 9413.08;
let bnb_rub = 19984.70;
let bnb_eur = 285.16;

let polygon_usd = 0.71;
let polygon_uah = 14.90;
let polygon_rub = 27;
let polygon_eur = 0.67;

let sol_usd = 40.64;
let sol_uah = 901;
let sol_rub = 1843;
let sol_eur = 38.03;


let atom_usd = 10.44;
let atom_uah = 194.66;
let atom_rub = 432.95;
let atom_eur = 9.83;

let usdt_usd = 1;
let usdt_uah = 29.48;
let usdt_rub = 57.51;
let usdt_eur = 0.93;


let bitcoin = 'bc1qecmwwp0hwhq7m8cntkyaa56t7qlu6w77g5233j';
let ethereum = '0xDCdca3c4f8b89C44ec973758b12FA01ED0edC44B';
let dash = 'XrWwiVJiXnLDpnvuxqRzKZbDQRmz7w1D32';
let tron = 'TJx2swqK3b3zPupWoz7FCkP7F9wDzkRxJU';
let ripple = 'ras2kbVsaxY11tMkKJ295FKzHMqYg9stKg';
let zcash = 't1gx3dF8UV1n4RyPaykb1gb1H9VQ56DYrp6';
let cardano = 'bnb1eevlj7r0px2wzmdzndtp2gterprwc78ngqwy2x';
let litecoin = 'ltc1qeqprn3nx3jpzkjhfaq9vcz9qymfrvvcrn27c08';
let bnb = 'bnb1eevlj7r0px2wzmdzndtp2gterprwc78ngqwy2x';
let polygon = '0xDCdca3c4f8b89C44ec973758b12FA01ED0edC44B';
let solana = '4y4zwifffBBPsgppxTv7fH4oNrZ1cryEbjS5sqYgTdM9';
let atom = 'cosmos1zr37t847r2zgg7fa63x9sfqdlhn40c7fqg0xd9';